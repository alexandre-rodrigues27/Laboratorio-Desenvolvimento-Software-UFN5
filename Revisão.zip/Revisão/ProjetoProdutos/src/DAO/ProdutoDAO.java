
package DAO;

import beans.Produto;
import beans.Categoria;
import conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {

    private Connection conn;

    public ProdutoDAO() {
        this.conn = new Conexao().getConexao();
    }

    // INSERIR PRODUTO
    public void inserir(Produto produto) {

        String sql = "INSERT INTO produtos (nome, preco, quantidade, categoria_id) VALUES (?, ?, ?, ?)";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, produto.getNome());
            stmt.setDouble(2, produto.getPreco());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setInt(4, produto.getCategoria().getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao inserir produto: " + ex.getMessage());
        }
    }

    // CONSULTAR TODOS OS PRODUTOS
    public List<Produto> getProdutos() {

        String sql = "SELECT p.*, c.nome AS categoria_nome FROM produtos p "
                   + "INNER JOIN categorias c ON p.categoria_id = c.id";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            List<Produto> listaProdutos = new ArrayList<>();

            while (rs.next()) {

                Produto p = new Produto();
                Categoria c = new Categoria();

                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getDouble("preco"));
                p.setQuantidade(rs.getInt("quantidade"));

                c.setId(rs.getInt("categoria_id"));
                c.setNome(rs.getString("categoria_nome"));

                p.setCategoria(c);

                listaProdutos.add(p);
            }

            return listaProdutos;

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar produtos: " + ex.getMessage());
            return null;
        }
    }

    // CONSULTAR PRODUTO POR ID
    public Produto getProduto(int id) {

        String sql = "SELECT * FROM produtos WHERE id = ?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                Produto p = new Produto();
                Categoria c = new Categoria();

                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getDouble("preco"));
                p.setQuantidade(rs.getInt("quantidade"));

                c.setId(rs.getInt("categoria_id"));

                p.setCategoria(c);

                return p;
            }

            return null;

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar produto: " + ex.getMessage());
            return null;
        }
    }

    // EDITAR PRODUTO
    public void editar(Produto produto) {

        String sql = "UPDATE produtos SET nome=?, preco=?, quantidade=?, categoria_id=? WHERE id=?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, produto.getNome());
            stmt.setDouble(2, produto.getPreco());
            stmt.setInt(3, produto.getQuantidade());
            stmt.setInt(4, produto.getCategoria().getId());
            stmt.setInt(5, produto.getId());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar produto: " + ex.getMessage());
        }
    }

    // EXCLUIR PRODUTO
    public void excluir(int id) {

        String sql = "DELETE FROM produtos WHERE id=?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao excluir produto: " + ex.getMessage());
        }
    }

    // BUSCAR PRODUTO POR NOME OU CATEGORIA
    public List<Produto> buscar(String pesquisa) {

        String sql = "SELECT p.*, c.nome AS categoria_nome FROM produtos p "
                   + "INNER JOIN categorias c ON p.categoria_id = c.id "
                   + "WHERE p.nome LIKE ? OR c.nome LIKE ?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, "%" + pesquisa + "%");
            stmt.setString(2, "%" + pesquisa + "%");

            ResultSet rs = stmt.executeQuery();

            List<Produto> listaProdutos = new ArrayList<>();

            while (rs.next()) {

                Produto p = new Produto();
                Categoria c = new Categoria();

                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getDouble("preco"));
                p.setQuantidade(rs.getInt("quantidade"));

                c.setId(rs.getInt("categoria_id"));
                c.setNome(rs.getString("categoria_nome"));

                p.setCategoria(c);

                listaProdutos.add(p);
            }

            return listaProdutos;

        } catch (SQLException ex) {
            System.out.println("Erro ao buscar produtos: " + ex.getMessage());
            return null;
        }
    }

}
