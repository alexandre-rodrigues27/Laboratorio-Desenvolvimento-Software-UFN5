package DAO;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import beans.Categoria;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CategoriaDAO {

    private Connection conn;

    public CategoriaDAO() {
        this.conn = new Conexao().getConexao();
    }

    public Categoria getCategoria(int id) {
        String sql = "SELECT * FROM categorias WHERE id = ?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Categoria c = new Categoria();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));

                return c;
            }

            return null;

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar categoria: " + ex.getMessage());
            return null;
        }
    }

    public void inserir(Categoria categoria) {

        String sql = "INSERT INTO categorias (nome) VALUES (?)";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, categoria.getNome());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao inserir categoria: " + ex.getMessage());
        }
    }

    public void editar(Categoria categoria) {
        String sql = "UPDATE categorias SET nome = ? WHERE id = ?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, categoria.getNome());
            stmt.setInt(2, categoria.getId());
            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar categoria: " + ex.getMessage());
        }
    }

    public List<Categoria> getCategorias() {

        String sql = "SELECT * FROM categorias";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            List<Categoria> listaCategorias = new ArrayList<>();

            while (rs.next()) {

                Categoria c = new Categoria();

                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));

                listaCategorias.add(c);
            }

            return listaCategorias;

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar categorias: " + ex.getMessage());
            return null;
        }
    }

}
