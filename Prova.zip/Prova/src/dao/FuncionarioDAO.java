/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Funcionario;
import conexao.Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioDAO {
    
    private Connection conn;
    
    public FuncionarioDAO() {
        this.conn = new Conexao().getConexao();
    }

    // INSERIR PRODUTO
    public void inserir(Funcionario funcionario) {

        String sql = "INSERT INTO funcionarios (nome, idade, genero, cargo, salario) VALUES (?, ?, ?, ?, ?)";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, funcionario.getNome());
            stmt.setInt(2, funcionario.getIdade());
            stmt.setString(3, funcionario.getGenero());
            stmt.setString(4, funcionario.getCargo());
            stmt.setDouble(5, funcionario.getSalario());

            stmt.execute();

        } catch (SQLException ex) {
            System.out.println("Erro ao inserir funcionario: " + ex.getMessage());
        }
    }
    
    public Funcionario getPessoa(int id) {
        String sql = "SELECT *FROM pessoa WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Funcionario f = new Funcionario();
            rs.first();
            f.setId(id);
            f.setNome(rs.getString("nome"));
            f.setIdade(rs.getInt("idade"));
            f.setGenero(rs.getString("genero"));
            f.setCargo(rs.getString("cargo"));
            f.setSalario(rs.getDouble("salario"));
            return f;

        } catch (Exception ex) {
            System.out.println("Erro ao consultar pessoa" + ex.getMessage());
            return null;
        }
    }
    
    public List<Funcionario> getFuncionario() {

        String sql = "SELECT * FROM funcionarios ";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            List<Funcionario> listaFuncionarios = new ArrayList<>();

            while (rs.next()) {

                Funcionario f = new Funcionario();

                f.setId(rs.getInt("id"));
                f.setNome(rs.getString("nome"));
                f.setIdade(rs.getInt("idade"));
                f.setGenero(rs.getString("genero"));
                f.setCargo(rs.getString("cargo"));
                f.setSalario(rs.getDouble("salario"));

                listaFuncionarios.add(f);
            }

            return listaFuncionarios;

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar produtos: " + ex.getMessage());
            return null;
        }
    }
}
