package projeto;

public class Aluno {

    private String nomeCompleto;
    private String dataNascimento;
    private char sexo;
    private String matricula;
    private String curso;
    private String cpf;
    private String rua;
    private String numero;
    private String bairro;
    private String cidade;
    private String cep;
    private String estado;
    private String telefone;

    public Aluno(String nomeCompleto, String dataNascimento, char sexo,
                 String matricula, String curso, String cpf,
                 String rua, String numero, String bairro,
                 String cidade, String cep, String estado,
                 String telefone) {

        this.nomeCompleto = nomeCompleto;
        this.dataNascimento = dataNascimento;
        this.sexo = sexo;
        this.matricula = matricula;
        this.curso = curso;
        this.cpf = cpf;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.cep = cep;
        this.estado = estado;
        this.telefone = telefone;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public char getSexo() {
        return sexo;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getCurso() {
        return curso;
    }

    public String getCpf() {
        return cpf;
    }

    public String getRua() {
        return rua;
    }

    public String getNumero() {
        return numero;
    }

    public String getBairro() {
        return bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public String getCep() {
        return cep;
    }

    public String getEstado() {
        return estado;
    }

    public String getTelefone() {
        return telefone;
    }

    public String paraLinhaTexto() {
        return nomeCompleto + "; " +
               dataNascimento + "; " +
               sexo + "; " +
               matricula + "; " +
               curso + "; " +
               cpf + " ;" +
               rua + "; " +
               numero + "; " +
               bairro + "; " +
               cidade + "; " +
               cep + "; " +
               estado + "; " +
               telefone;
    }

    public static Aluno deLinhaTexto(String linha) {

        String[] dados = linha.split(";", -1);

        return new Aluno(
            dados[0],
            dados[1],
            dados[2].charAt(0),
            dados[3],
            dados[4],
            dados[5],
            dados[6],
            dados[7],
            dados[8],
            dados[9],
            dados[10],
            dados[11],
            dados[12]
        );
    }
}