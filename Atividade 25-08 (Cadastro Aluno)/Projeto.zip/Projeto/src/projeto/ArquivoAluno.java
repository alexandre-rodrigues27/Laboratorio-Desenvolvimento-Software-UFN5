package projeto;

import java.io.*;
import java.util.ArrayList;

public class ArquivoAluno {

    private static final String NOME_ARQUIVO = "alunos.txt";

    public static void salvar(ArrayList<Aluno> lista) {

        try (BufferedWriter writer =
                new BufferedWriter(new FileWriter(NOME_ARQUIVO))) {

            for (Aluno aluno : lista) {
                writer.write(aluno.paraLinhaTexto());
                writer.newLine();
            }

        } catch (IOException e) {
            javax.swing.JOptionPane.showMessageDialog(
                null,
                "Erro ao salvar arquivo: " + e.getMessage()
            );
        }
    }

    public static ArrayList<Aluno> carregar() {

        ArrayList<Aluno> lista = new ArrayList<>();

        File arquivo = new File(NOME_ARQUIVO);

        if (!arquivo.exists()) {
            return lista;
        }

        try (BufferedReader reader =
                new BufferedReader(new FileReader(arquivo))) {

            String linha;

            while ((linha = reader.readLine()) != null) {

                if (!linha.trim().isEmpty()) {
                    lista.add(Aluno.deLinhaTexto(linha));
                }
            }

        } catch (IOException | RuntimeException e) {

            javax.swing.JOptionPane.showMessageDialog(
                null,
                "Erro ao carregar arquivo: " + e.getMessage()
            );
        }

        return lista;
    }
}