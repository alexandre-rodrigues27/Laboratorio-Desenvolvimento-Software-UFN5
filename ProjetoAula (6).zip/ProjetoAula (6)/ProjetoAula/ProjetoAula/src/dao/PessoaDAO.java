/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Pessoa;
import java.sql.Connection;
import conexao.Conexao;
import java.util.List;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author laboratorio
 */
public class PessoaDAO {
    
    private Conexao conexao;
    private Connection conn;
    
    public PessoaDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir(Pessoa pessoa) {
        try {
            String sql = "INSERT INTO pessoa(nome, sexo, idioma) VALUES (?, ?, ?);";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, pessoa.getNome());
            stmt.setString(2, pessoa.getSexo());
            stmt.setString(3, pessoa.getIdioma());
            
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir pessoa: " + ex.getMessage());
        }
    }
    
    public void inserir(String nome, String sexo, String idioma) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public Pessoa getPessoa(int id) {
        
        String sql = "SELECT *FROM pessoa WHERE id = ?";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            //1º parâmentro é o SQL
            //2º parâmentro é o tipo do ResultSet -
            stmt.setInt(1, id);
            ResultSet ra = stmt.executeQuery();
            Pessoa p = new Pessoa();
            ra.first();
            p.setId(id);
            p.setNome(ra.getString("nome"));
            p.setSexo(ra.getString("sexo"));
            p.setIdioma(ra.getString("idioma"));
            return p;
            
        } catch (Exception ex) {
            System.out.println("Erro ao consultar pessoa" + ex.getMessage());
            return null;
        }
    }
    
    public void editar(Pessoa pessoa) {
        
        try {
            String sql = "UPDATE pessoa set nome=?, sexo=?, idioma=? WHERE id=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, pessoa.getNome());
            stmt.setString(2, pessoa.getSexo());
            stmt.setString(3, pessoa.getIdioma());
            stmt.setInt(4, pessoa.getId());
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar pessoa: " + ex.getMessage());
        }
    }
    
    public void excluir(int id) {
        
        try {
            String sql = "delete frompessoa WHERE id=?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir pessoa: " + ex.getMessage());
        }
    }
    
    public List<Pessoa> getPessoas() {
        
        String sql = "SELECT * FROM pessoa";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            List<Pessoa> listaPessoas = new ArrayList();
            while (rs.next()) {
                Pessoa p = new Pessoa();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setSexo(rs.getString("sexo"));
                p.setIdioma(rs.getString("idioma"));
                listaPessoas.add(p);
            }
            return listaPessoas;
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar todas as pessoas: " + ex.getMessage());
            return null;
        }
    }
    
    public List<Pessoa> getPessoasNome(String nome, String sexo) {
        
        String sql = "SELECT * FROM pessoa WHERE nome LIKE ? AND sexo LIKE ?";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1, "%" + nome + "%");
            stmt.setString(2, "%" + sexo + "%");
            ResultSet rs = stmt.executeQuery();
            List<Pessoa> listaPessoas = new ArrayList();
            
            while (rs.next()) {
                Pessoa p = new Pessoa();
                p.setId(rs.getInt("Id"));
                p.setNome(rs.getString("nome"));
                p.setSexo(rs.getString("sexo"));
                p.setIdioma(rs.getString("idioma"));
                listaPessoas.add(p);
            }
            return listaPessoas;
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar todas as pessoas: " + ex.getMessage());
            return null;
        }
    }
}
