/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author laboratorio
 */
public class Principal {

    public static void main(String[] args) throws IOException {
        int porta = 12345; // Use uma constante para a porta

        try (ServerSocket servidorSocket = new ServerSocket(porta)) {
            System.out.println("Servidor aguardando conexões na porta " + porta);

            while (true) {
                try {
                    Socket clienteSocket = servidorSocket.accept();
                    System.out.println("Conexão aceita de " + clienteSocket.getInetAddress());

                    // Simule a obtenção de uma Pessoa a partir do ID
                    Thread threadCliente = new ThreadServer(clienteSocket);
                    threadCliente.start();

                } catch (IOException ex) {
                    System.out.println("Erro ao aceitar conexão do cliente");
                }
            }

        } catch (IOException ex) {
            System.out.println("Erro ao criar o ServerSocket");
        }
    }
}
