/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Pessoa;
import java.sql.Connection;
import conexao.Conexao;
import java.util.List;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author laboratorio
 */
public class PessoaDAO {
    private Conexao conexao;
    private Connection conn;
    
    public PessoaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir (Pessoa pessoa){
        try {
            String sql = "INSERT INTO pessoa(nome, sexo, idioma) VALUES (?, ?, ?);";
            PreparedStatement stnt = this.conn.prepareStatement(sql);
            stnt.setString(1,pessoa.getNome());
            stnt.setString(2,pessoa.getSexo());
            stnt.setString(3,pessoa.getIdioma());
            
            stnt.execute();
        } catch (SQLException ex){
            System.out.println("Erro ao inserir pessoa: " + ex.getMessage());
        }
    }

    public void inserir(String nome, String sexo, String idioma) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
